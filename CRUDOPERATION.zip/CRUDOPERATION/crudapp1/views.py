from django.shortcuts import render,redirect
from crudapp1.models import Hospital
from crudapp1.forms import HospitalForm

# Create your views here.
def read_data(request):
    hospital_list = Hospital.objects.all()
    context = {
        "hospital_list":hospital_list
    }
    return render(request,"read.html",context)

def read_one_data(request,id):
    hospital = Hospital.objects.get(id=id)
    context ={
        'hospital':hospital
    }
    return render(request,"readone.html",context)
    
def insert_data(request):
    form = HospitalForm()
    if request.method == "POST":
        form = HospitalForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("/home")
    return render(request,"insert.html",{'form':form})    

def delete_one_data(request,id):
    Hospital_data = Hospital.objects.get(id=id)
    Hospital_data.delete()
    return redirect("/home")

def update_one_data(request,id):
    Hospital_one_data = Hospital.objects.get(id=id)
    if request.method == "POST":
        form = HospitalForm(request.POST, instance=Hospital_one_data)
        if form.is_valid():
            form.save()
            return redirect("/home")
    return render(request,"update.html",{'Hospital_one_data':Hospital_one_data})
