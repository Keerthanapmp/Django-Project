from django import forms
from crudapp1.models import Hospital

class HospitalForm(forms.ModelForm):
    class Meta:
        model = Hospital
        fields = "__all__"